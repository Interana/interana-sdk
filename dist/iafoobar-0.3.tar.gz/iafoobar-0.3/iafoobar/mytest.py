from datetime import datetime
import json

import requests


SINGLE_MEASURE = 'single_measurement'
TIME_SERIES = 'time_series'

def test_module():
	print("foobar")

